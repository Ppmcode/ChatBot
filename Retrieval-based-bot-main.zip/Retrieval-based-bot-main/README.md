# Retrieval-based-bot
Created a retrieval based chatbot
